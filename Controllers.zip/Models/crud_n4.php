<?php

require_once "Models/conexion.php";


class Datosncua extends Conexion{
	# CLASE NIVEL 1n1


	public function vistancuaModel($datosModel,$tabla){
		$stmt = Conexion::conectar()-> prepare("SELECT n4_id, n4_nombre FROM $tabla WHERE n4_idn3=:idn3");
		$stmt-> bindParam(":idn3", $datosModel, PDO::PARAM_INT);
		
		$stmt-> execute();

		return $stmt->fetchAll();
	}
}


?>