	<?php

require_once "Models/conexion.php";


class Datosnuno extends Conexion{
	# CLASE NIVEL 1n1


	public function vistaN1Model($tabla){
		$stmt = Conexion::conectar()-> prepare("SELECT n1_id, n1_nombre FROM $tabla ");
		
		$stmt-> execute();

		return $stmt->fetchAll();
	}
}


?>