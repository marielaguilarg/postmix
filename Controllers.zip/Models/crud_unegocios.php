<?php

require_once "Models/conexion.php";


class DatosUnegocio extends Conexion{

#vistaservicios

	public function vistaUnegocioModel($tabla){
		$stmt = Conexion::conectar()-> prepare("SELECT une_id, une_descripcion, une_idpepsi, une_idcuenta FROM $tabla");
				
		$stmt-> execute();

		return $stmt->fetchAll();
		$stmt->close();
	}


	public function vistaFiltroUnegocioModel($datosbus, $tabla){
		$stmt = Conexion::conectar()-> prepare("SELECT une_id, une_descripcion, une_idpepsi, une_idcuenta FROM $tabla where une_descripcion LIKE :opbusqueda");
	
		$stmt-> bindParam(":opbusqueda", $datosbus, PDO::PARAM_STR);
		$stmt-> execute();

		return $stmt->fetchAll();
	
		$stmt->close();

	}

}

?>	