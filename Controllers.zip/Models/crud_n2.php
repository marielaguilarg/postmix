<?php

require_once "Models/conexion.php";


class Datosndos extends Conexion{
	# CLASE NIVEL 1n1


	public function vistandosModel($datosModel,$tabla){
		$stmt = Conexion::conectar()-> prepare("SELECT n2_id, n2_nombre FROM $tabla WHERE n2_idn1=:idn1");
		$stmt-> bindParam(":idn1", $datosModel, PDO::PARAM_INT);
		
		$stmt-> execute();

		return $stmt->fetchAll();
	}
}


?>