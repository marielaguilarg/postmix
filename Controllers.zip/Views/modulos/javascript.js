$(document).ready(function() {
    $('#lanzar_alerta').click(function() {
        alert('hola mundo!');
    });
});