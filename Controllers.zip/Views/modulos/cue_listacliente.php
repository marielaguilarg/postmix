<section class="content container-fluid">
 <h1>Clientes &nbsp; &nbsp;</h1>

<?php

$ingreso = new MvcController();
$ingreso -> vistaClientesController();
$ingreso -> borrarClienteController();

?>

</section>