<section class="content-header">
<h1>Nivel 1 &nbsp; &nbsp;</h1>
</section>
<section class="content container-fluid">
 

<?php

$ingreso = new NunoController();
$ingreso -> vistanunoController();

?>

</section>