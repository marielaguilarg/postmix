 <section class="content-header">
  <h1> EDITA REACTIVO</h1>
   
   </section>
  <section class="content container-fluid">
  <div class="row">
    <div class="col-md-12">
        <div class="box box-info">
            <div class="box-header with-border">
           <form role="form" method="post">      

  <?php

              $registro = New PonderacionController();
              $registro-> editarPonderaController();
             $registro-> actualizarPonderaController();
              ?>
              </form>
              </div>

          </div>
    </div>
  </div>
        </section>
      
    <!-- /.content -->
 
