 <section class="content-header">
      <h1>SERVICIO &nbsp; &nbsp;</h1>
      
    </section>

    <!-- Main content -->
    <section class="content container-fluid">


<?php

$ingreso = new servicioController();
$ingreso -> borrarServicioController();
$ingreso -> vistaServiciosController();

?>

</section>