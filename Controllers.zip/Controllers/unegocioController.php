<?php
class unegocioController{


	public function vistaunegocioController(){
		if(isset($_POST["opcionuneg"])){
			$op="%".$_POST["opcionuneg"]."%";
			//echo $op;
			$respuesta =Datosunegocio::vistaFiltroUnegocioModel($op, "ca_unegocios");
		} else {	
			$respuesta =Datosunegocio::vistaUnegocioModel("ca_unegocios");
		}
		foreach($respuesta as $row => $item){
			echo '  <tr>
	                  <td>'.$item["une_id"].'</td>
	                  <td>'.$item["une_idpepsi"].'</td>
		                  <td>'.$item["une_idcuenta"].'</td>
	                  <td>
	                    <a href="#">'.$item["une_descripcion"].'</a>
	                  </td>
	                </tr>';
	            
		}
	}

	
}

?>